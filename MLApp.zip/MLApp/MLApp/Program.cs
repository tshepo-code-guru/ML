﻿using System;

namespace MLApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Add input data
            
        }
    }
}